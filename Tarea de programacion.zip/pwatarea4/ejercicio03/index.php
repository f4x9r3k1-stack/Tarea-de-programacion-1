<?php
// Aquí va el ejercicio 3. Todo lo suyo (PHP, CSS, JS) se guarda en esta carpeta.
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Ejercicio 3</title>
  <link rel="stylesheet" href="../assets/css/portal.css">
</head>
<body>
  <main class="vacia">
    <h1>Ejercicio 3</h1>
    <p>Este ejercicio todavía no está desarrollado.</p>
    <p><a href="../index.php">Volver al menú</a></p>
  </main>
</body>
</html>
