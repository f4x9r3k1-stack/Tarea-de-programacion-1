<?php
// Funciones que se usan en casi todas las páginas del ejercicio.
require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

/* ---------------------------------------------------------------
   Utilidades generales
   --------------------------------------------------------------- */

// Escapa texto antes de imprimirlo en HTML (evita XSS)
function e(?string $texto): string
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}

function redirigir(string $destino): void
{
    header('Location: ' . $destino);
    exit;
}

// Mensajes que se muestran una sola vez (después de una redirección)
function flash(string $tipo, string $mensaje): void
{
    $_SESSION['flash'] = ['tipo' => $tipo, 'mensaje' => $mensaje];
}

function leer_flash(): ?array
{
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ---------------------------------------------------------------
   Protección CSRF
   --------------------------------------------------------------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_valido(?string $token): bool
{
    return !empty($token) && hash_equals($_SESSION['csrf'] ?? '', $token);
}

/* ---------------------------------------------------------------
   Usuario actual, roles y permisos
   --------------------------------------------------------------- */

// Trae el usuario logueado con su rol y la lista de permisos.
// Se consulta en cada petición para que un cambio de rol hecho por
// el admin se aplique al instante.
function usuario_actual(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }

    if (empty($_SESSION['usuario_id'])) {
        return $cache = null;
    }

    $db = conectar();

    $st = $db->prepare(
        'SELECT u.id, u.nombre, u.usuario, r.id AS rol_id, r.nombre AS rol
           FROM usuarios u
           JOIN roles r ON r.id = u.rol_id
          WHERE u.id = ?'
    );
    $st->execute([$_SESSION['usuario_id']]);
    $u = $st->fetch();

    if (!$u) {
        // el usuario fue borrado mientras tenía la sesión abierta
        unset($_SESSION['usuario_id']);
        return $cache = null;
    }

    $st = $db->prepare(
        'SELECT p.clave
           FROM rol_permiso rp
           JOIN permisos p ON p.id = rp.permiso_id
          WHERE rp.rol_id = ?'
    );
    $st->execute([$u['rol_id']]);
    $u['permisos'] = $st->fetchAll(PDO::FETCH_COLUMN);

    return $cache = $u;
}

function puede(string $permiso): bool
{
    $u = usuario_actual();
    return $u !== null && in_array($permiso, $u['permisos'], true);
}

function requiere_login(): array
{
    $u = usuario_actual();
    if ($u === null) {
        redirigir('login.php');
    }
    return $u;
}

function requiere_permiso(string $permiso): array
{
    $u = requiere_login();
    if (!puede($permiso)) {
        http_response_code(403);
        die('403 - Tu rol no tiene permiso para entrar a esta página. '
          . '<a href="tareas.php">Volver a mis tareas</a>');
    }
    return $u;
}

/* ---------------------------------------------------------------
   Tareas
   --------------------------------------------------------------- */

// Reglas de permisos sobre una tarea concreta.
// "Marcar propias" aplica a tareas asignadas al usuario;
// "eliminar propias" aplica a tareas que el usuario creó.
function puede_marcar(array $tarea): bool
{
    $u = usuario_actual();
    if ($u === null) {
        return false;
    }
    if (puede('marcar_todas')) {
        return true;
    }
    return puede('marcar_propias') && (int)$tarea['asignado_a'] === (int)$u['id'];
}

function puede_eliminar(array $tarea): bool
{
    $u = usuario_actual();
    if ($u === null) {
        return false;
    }
    if (puede('eliminar_todas')) {
        return true;
    }
    return puede('eliminar_propias') && (int)$tarea['creado_por'] === (int)$u['id'];
}

// Consulta base. Si el usuario no ve todas las tareas, se filtra
// por las que tiene asignadas o creó.
const SQL_TAREAS =
    'SELECT t.*, ua.nombre AS asignado_nombre, uc.nombre AS creador_nombre
       FROM tareas t
       JOIN usuarios ua ON ua.id = t.asignado_a
  LEFT JOIN usuarios uc ON uc.id = t.creado_por';

function obtener_tareas(): array
{
    $u  = usuario_actual();
    $db = conectar();

    if (puede('ver_todas')) {
        $st = $db->query(SQL_TAREAS . ' ORDER BY t.completada ASC, t.creado_en DESC, t.id DESC');
    } else {
        $st = $db->prepare(
            SQL_TAREAS . ' WHERE t.asignado_a = :asignado OR t.creado_por = :creador
              ORDER BY t.completada ASC, t.creado_en DESC, t.id DESC'
        );
        $st->execute(['asignado' => $u['id'], 'creador' => $u['id']]);
    }
    return $st->fetchAll();
}

function obtener_tarea(int $id): ?array
{
    $st = conectar()->prepare(SQL_TAREAS . ' WHERE t.id = ?');
    $st->execute([$id]);
    $fila = $st->fetch();
    return $fila ?: null;
}

// Genera el HTML de una tarea. Se usa al cargar la página y también
// cuando JavaScript agrega una tarea nueva sin recargar.
function render_tarea(array $t): string
{
    $hoy      = date('Y-m-d');
    $vencida  = !$t['completada'] && $t['fecha_limite'] && $t['fecha_limite'] < $hoy;
    $marcable = puede_marcar($t);
    $borrable = puede_eliminar($t);

    ob_start();
    include __DIR__ . '/tarea_item.php';
    return ob_get_clean();
}
