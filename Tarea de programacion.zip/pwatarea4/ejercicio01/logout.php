<?php
require_once 'funciones.php';

// Se destruye la sesión completa, incluida la cookie
$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}
session_destroy();

session_start();
flash('ok', 'Cerraste sesión correctamente.');
redirigir('login.php');
