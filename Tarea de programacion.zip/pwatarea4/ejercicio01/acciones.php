<?php
// Recibe las peticiones AJAX de tareas.php (crear, marcar y eliminar)
// y siempre responde en JSON.
require_once 'funciones.php';

header('Content-Type: application/json; charset=utf-8');

function responder(array $datos, int $codigo = 200): void
{
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    responder(['ok' => false, 'mensaje' => 'Método no permitido.'], 405);
}

$u = usuario_actual();
if ($u === null) {
    responder(['ok' => false, 'mensaje' => 'Tu sesión expiró. Inicia sesión otra vez.'], 401);
}

if (!csrf_valido($_POST['csrf'] ?? null)) {
    responder(['ok' => false, 'mensaje' => 'Petición no válida. Recarga la página.'], 403);
}

$db     = conectar();
$accion = $_POST['accion'] ?? '';

try {
    switch ($accion) {

        /* ---------- crear ---------- */
        case 'crear':
            if (!puede('crear')) {
                responder(['ok' => false, 'mensaje' => 'Tu rol no puede agregar tareas.'], 403);
            }

            $titulo      = trim($_POST['titulo'] ?? '');
            $descripcion = trim($_POST['descripcion'] ?? '');
            $prioridad   = $_POST['prioridad'] ?? 'media';
            $fecha       = trim($_POST['fecha_limite'] ?? '');

            if ($titulo === '' || mb_strlen($titulo) > 120) {
                responder(['ok' => false, 'mensaje' => 'El título es obligatorio (máximo 120 caracteres).'], 422);
            }
            if (mb_strlen($descripcion) > 500) {
                responder(['ok' => false, 'mensaje' => 'El detalle no puede pasar de 500 caracteres.'], 422);
            }
            if (!in_array($prioridad, ['baja', 'media', 'alta'], true)) {
                responder(['ok' => false, 'mensaje' => 'Prioridad no válida.'], 422);
            }

            if ($fecha !== '') {
                $d = DateTime::createFromFormat('Y-m-d', $fecha);
                if (!$d || $d->format('Y-m-d') !== $fecha) {
                    responder(['ok' => false, 'mensaje' => 'La fecha límite no es válida.'], 422);
                }
            } else {
                $fecha = null;
            }

            // Por defecto la tarea es para quien la crea. Solo quien tiene
            // el permiso "asignar" puede mandársela a otra persona.
            $asignado = (int)$u['id'];
            if (puede('asignar') && !empty($_POST['asignado_a'])) {
                $st = $db->prepare('SELECT COUNT(*) FROM usuarios WHERE id = ?');
                $st->execute([(int)$_POST['asignado_a']]);
                if (!$st->fetchColumn()) {
                    responder(['ok' => false, 'mensaje' => 'El usuario elegido no existe.'], 422);
                }
                $asignado = (int)$_POST['asignado_a'];
            }

            $st = $db->prepare(
                'INSERT INTO tareas (titulo, descripcion, prioridad, fecha_limite, creado_por, asignado_a)
                 VALUES (?, ?, ?, ?, ?, ?)'
            );
            $st->execute([
                $titulo,
                $descripcion !== '' ? $descripcion : null,
                $prioridad,
                $fecha,
                $u['id'],
                $asignado,
            ]);

            $tarea = obtener_tarea((int)$db->lastInsertId());

            // Si la tarea es para otra persona y yo no veo todas, no tiene
            // sentido pintarla en mi lista; solo aviso que se creó.
            $visible = puede('ver_todas') || $asignado === (int)$u['id'];

            responder([
                'ok'      => true,
                'mensaje' => 'Tarea agregada.',
                'visible' => $visible,
                'html'    => $visible ? render_tarea($tarea) : '',
            ]);
            break;

        /* ---------- marcar / desmarcar ---------- */
        case 'marcar':
            $tarea = obtener_tarea((int)($_POST['id'] ?? 0));
            if (!$tarea) {
                responder(['ok' => false, 'mensaje' => 'Esa tarea ya no existe.'], 404);
            }
            if (!puede_marcar($tarea)) {
                responder(['ok' => false, 'mensaje' => 'Tu rol no puede cambiar el estado de esta tarea.'], 403);
            }

            $hecha = ($_POST['hecha'] ?? '0') === '1' ? 1 : 0;

            $st = $db->prepare(
                'UPDATE tareas SET completada = ?, completada_en = ' . ($hecha ? 'NOW()' : 'NULL') . ' WHERE id = ?'
            );
            $st->execute([$hecha, $tarea['id']]);

            responder([
                'ok'      => true,
                'mensaje' => $hecha ? 'Tarea marcada como hecha.' : 'Tarea marcada como pendiente.',
                'hecha'   => (bool)$hecha,
            ]);
            break;

        /* ---------- eliminar ---------- */
        case 'eliminar':
            $tarea = obtener_tarea((int)($_POST['id'] ?? 0));
            if (!$tarea) {
                responder(['ok' => false, 'mensaje' => 'Esa tarea ya no existe.'], 404);
            }
            if (!puede_eliminar($tarea)) {
                responder(['ok' => false, 'mensaje' => 'Tu rol no puede eliminar esta tarea.'], 403);
            }

            $st = $db->prepare('DELETE FROM tareas WHERE id = ?');
            $st->execute([$tarea['id']]);

            responder(['ok' => true, 'mensaje' => 'Tarea eliminada.']);
            break;

        default:
            responder(['ok' => false, 'mensaje' => 'Acción desconocida.'], 400);
    }
} catch (PDOException $e) {
    // El detalle del error no se muestra al usuario
    error_log('acciones.php: ' . $e->getMessage());
    responder(['ok' => false, 'mensaje' => 'Ocurrió un error con la base de datos. Intenta de nuevo.'], 500);
}
