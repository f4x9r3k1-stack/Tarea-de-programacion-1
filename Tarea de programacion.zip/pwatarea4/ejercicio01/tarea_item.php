<?php
// Plantilla de una tarea. Se incluye desde render_tarea() en funciones.php,
// que le pasa las variables $t, $vencida, $marcable y $borrable.
$textoBusqueda = mb_strtolower($t['titulo'] . ' ' . ($t['descripcion'] ?? '') . ' ' . $t['asignado_nombre']);
?>
<li class="tarea prioridad-<?= e($t['prioridad']) ?><?= $t['completada'] ? ' hecha' : '' ?><?= $vencida ? ' vencida' : '' ?>"
    data-id="<?= (int)$t['id'] ?>"
    data-estado="<?= $t['completada'] ? 'hecha' : 'pendiente' ?>"
    data-limite="<?= e($t['fecha_limite'] ?? '') ?>"
    data-texto="<?= e($textoBusqueda) ?>">

  <label class="check" <?= $marcable ? '' : 'title="Tu rol no puede cambiar el estado de esta tarea"' ?>>
    <input type="checkbox" class="chk-marcar"
           <?= $t['completada'] ? 'checked' : '' ?>
           <?= $marcable ? '' : 'disabled' ?>
           aria-label="Marcar como hecha: <?= e($t['titulo']) ?>">
    <span class="caja"></span>
  </label>

  <div class="cuerpo">
    <h3 class="titulo"><?= e($t['titulo']) ?></h3>
    <?php if (!empty($t['descripcion'])): ?>
      <p class="desc"><?= e($t['descripcion']) ?></p>
    <?php endif; ?>

    <div class="meta">
      <span class="etiqueta etiqueta-<?= e($t['prioridad']) ?>">Prioridad <?= e($t['prioridad']) ?></span>
      <span class="dato">Para <strong><?= e($t['asignado_nombre']) ?></strong></span>
      <?php if ($t['fecha_limite']): ?>
        <span class="dato fecha">
          <span class="fecha-pref"><?= $vencida ? 'Venció el' : 'Entrega' ?></span> <?= e(date('d/m/Y', strtotime($t['fecha_limite']))) ?>
        </span>
      <?php endif; ?>
      <?php if (!empty($t['creador_nombre']) && $t['creado_por'] != $t['asignado_a']): ?>
        <span class="dato">Creada por <?= e($t['creador_nombre']) ?></span>
      <?php endif; ?>
    </div>
  </div>

  <?php if ($borrable): ?>
    <button type="button" class="btn-borrar" aria-label="Eliminar tarea: <?= e($t['titulo']) ?>">Eliminar</button>
  <?php endif; ?>
</li>
