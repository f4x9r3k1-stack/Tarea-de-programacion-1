<?php
require_once 'funciones.php';
$u = requiere_login();

$tareas = obtener_tareas();

// Solo quien puede asignar necesita la lista de usuarios para el <select>
$usuarios = [];
if (puede('asignar')) {
    $usuarios = conectar()->query('SELECT id, nombre FROM usuarios ORDER BY nombre')->fetchAll();
}

$total      = count($tareas);
$hechas     = count(array_filter($tareas, fn($t) => $t['completada']));
$pendientes = $total - $hechas;

$titulo = 'Tareas';
$scripts = ['js/app.js'];
include 'cabecera.php';
?>

<div class="encabezado-pagina">
  <h1><?= puede('ver_todas') ? 'Todas las tareas' : 'Mis tareas' ?></h1>
  <p class="sub">
    <?php if (puede('ver_todas')): ?>
      Estás viendo las tareas de todos los usuarios.
    <?php else: ?>
      Aquí aparecen las tareas que tienes asignadas o que tú creaste.
    <?php endif; ?>
  </p>
</div>

<div class="panel">

  <aside class="lateral">
    <?php if (puede('crear')): ?>
      <section class="caja-form" aria-labelledby="t-nueva">
        <h2 id="t-nueva">Nueva tarea</h2>

        <form id="form-tarea" autocomplete="off" novalidate>
          <label for="titulo">Título</label>
          <input type="text" id="titulo" name="titulo" maxlength="120" required placeholder="Ej: Entregar el informe">

          <label for="descripcion">Detalle <span class="opcional">(opcional)</span></label>
          <textarea id="descripcion" name="descripcion" rows="3" maxlength="500"></textarea>

          <div class="fila-2">
            <div>
              <label for="prioridad">Prioridad</label>
              <select id="prioridad" name="prioridad">
                <option value="baja">Baja</option>
                <option value="media" selected>Media</option>
                <option value="alta">Alta</option>
              </select>
            </div>
            <div>
              <label for="fecha_limite">Fecha límite</label>
              <input type="date" id="fecha_limite" name="fecha_limite" min="<?= date('Y-m-d') ?>">
            </div>
          </div>

          <?php if (puede('asignar')): ?>
            <label for="asignado_a">Asignar a</label>
            <select id="asignado_a" name="asignado_a">
              <?php foreach ($usuarios as $opt): ?>
                <option value="<?= (int)$opt['id'] ?>" <?= $opt['id'] == $u['id'] ? 'selected' : '' ?>>
                  <?= e($opt['nombre']) ?><?= $opt['id'] == $u['id'] ? ' (yo)' : '' ?>
                </option>
              <?php endforeach; ?>
            </select>
          <?php endif; ?>

          <button type="submit" class="btn btn-principal btn-ancho">Agregar tarea</button>
        </form>
      </section>
    <?php else: ?>
      <section class="caja-form caja-info">
        <h2>Solo lectura</h2>
        <p>Tu rol (<strong><?= e($u['rol']) ?></strong>) puede consultar las tareas que te asignaron, pero no agregarlas, marcarlas ni eliminarlas.</p>
        <p>Si necesitas más permisos, pídele a un administrador que cambie tu rol.</p>
      </section>
    <?php endif; ?>
  </aside>

  <section class="listado" aria-labelledby="t-lista">
    <h2 id="t-lista" class="solo-lectores">Listado de tareas</h2>

    <div class="herramientas">
      <input type="search" id="buscar" placeholder="Buscar por título o persona" aria-label="Buscar tareas">

      <div class="filtros" role="group" aria-label="Filtrar por estado">
        <button type="button" class="filtro activo" data-filtro="todas">Todas <span id="n-todas"><?= $total ?></span></button>
        <button type="button" class="filtro" data-filtro="pendiente">Pendientes <span id="n-pendiente"><?= $pendientes ?></span></button>
        <button type="button" class="filtro" data-filtro="hecha">Hechas <span id="n-hecha"><?= $hechas ?></span></button>
      </div>
    </div>

    <ul id="lista-tareas" class="lista-tareas">
      <?php foreach ($tareas as $t): ?>
        <?= render_tarea($t) ?>
      <?php endforeach; ?>
    </ul>

    <p id="vacio" class="vacio" <?= $total > 0 ? 'hidden' : '' ?>>
      <?= puede('crear')
          ? 'Todavía no hay tareas. Escribe la primera en el formulario de la izquierda.'
          : 'Todavía no tienes tareas asignadas.' ?>
    </p>
    <p id="sin-resultados" class="vacio" hidden>Ninguna tarea coincide con ese filtro o búsqueda.</p>
  </section>

</div>

<?php include 'pie.php'; ?>
