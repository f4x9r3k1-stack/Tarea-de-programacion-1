<?php
// Datos de conexión a MySQL.
// En Laragon/XAMPP el usuario es root y la clave va vacía.
// Si lo subes a un hosting gratuito, cambia estos valores por los que te den ahí.
define('DB_HOST', 'localhost');
define('DB_NAME', 'pwa_tareas');
define('DB_USER', 'root');
define('DB_PASS', '');

function conectar(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die('No se pudo conectar a la base de datos. Revisa los datos de config.php '
              . 'y que hayas importado database.sql.');
        }
    }
    return $pdo;
}
