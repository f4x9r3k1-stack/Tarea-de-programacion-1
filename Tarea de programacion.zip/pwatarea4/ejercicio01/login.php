<?php
require_once 'funciones.php';

if (usuario_actual()) {
    redirigir('tareas.php');
}

$error = '';
$usuario = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $clave   = $_POST['clave'] ?? '';

    if (!csrf_valido($_POST['csrf'] ?? null)) {
        $error = 'La página estuvo abierta demasiado tiempo. Vuelve a intentarlo.';
    } elseif ($usuario === '' || $clave === '') {
        $error = 'Escribe tu usuario y tu contraseña.';
    } else {
        $st = conectar()->prepare('SELECT id, clave FROM usuarios WHERE usuario = ?');
        $st->execute([$usuario]);
        $fila = $st->fetch();

        if ($fila && password_verify($clave, $fila['clave'])) {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = (int)$fila['id'];
            redirigir('tareas.php');
        }
        // mismo mensaje si falla el usuario o la clave, para no dar pistas
        $error = 'Usuario o contraseña incorrectos.';
    }
}

$titulo = 'Iniciar sesión';
$sin_menu = true;
include 'cabecera.php';
?>

<section class="acceso">
  <div class="acceso-form">
    <h1>Entrar a mis tareas</h1>
    <p class="sub">Usa tu cuenta para ver y gestionar las tareas según tu rol.</p>

    <?php if ($error): ?>
      <div class="aviso aviso-error" role="alert"><?= e($error) ?></div>
    <?php endif; ?>

    <form method="post" novalidate>
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

      <label for="usuario">Usuario</label>
      <input type="text" id="usuario" name="usuario" value="<?= e($usuario) ?>" autocomplete="username" required autofocus>

      <label for="clave">Contraseña</label>
      <input type="password" id="clave" name="clave" autocomplete="current-password" required>

      <button type="submit" class="btn btn-principal btn-ancho">Entrar</button>
    </form>

    <p class="pie-form">¿No tienes cuenta? <a href="registro.php">Crear una cuenta</a></p>
  </div>

  <aside class="acceso-ayuda">
    <h2>Cuentas de prueba</h2>
    <p>Para revisar cómo cambia el sistema según el rol:</p>
    <table class="tabla-mini">
      <thead><tr><th>Usuario</th><th>Clave</th><th>Rol</th></tr></thead>
      <tbody>
        <tr><td>admin</td><td>Admin123*</td><td>admin</td></tr>
        <tr><td>maria</td><td>Usuario123*</td><td>usuario</td></tr>
        <tr><td>luis</td><td>Lector123*</td><td>lector</td></tr>
      </tbody>
    </table>
    <ul class="lista-roles">
      <li><strong>admin</strong> ve todas las tareas, las asigna, las marca, las elimina y administra usuarios.</li>
      <li><strong>usuario</strong> agrega tareas, marca las que tiene asignadas y elimina las que creó.</li>
      <li><strong>lector</strong> solo consulta las tareas que le asignaron.</li>
    </ul>
  </aside>
</section>

<?php include 'pie.php'; ?>
