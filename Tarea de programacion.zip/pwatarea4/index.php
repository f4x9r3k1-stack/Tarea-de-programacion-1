<?php
// Portada de la tarea: menú con los cinco ejercicios.
$nombreTarea = 'Tarea de programación';
$asignatura  = 'Programación de web avanzada';
$integrantes = [
    'Danna Idrovo',
    'Madelen Toledo',
    'Diego Cobeña',
    'Jhoao Guala',
    'Keyla Duran',
    'Ckarlos Daza',
];

$ejercicios = [
    [
        'carpeta' => 'ejercicio01',
        'titulo'  => 'Lista de tareas interactiva',
        'detalle' => 'Login con roles y permisos (admin, usuario, lector), tareas guardadas en MySQL y acciones con AJAX.',
        'listo'   => true,
    ],
    ['carpeta' => 'ejercicio02', 'titulo' => 'Ejercicio 2', 'detalle' => 'Pendiente de desarrollar.', 'listo' => false],
    ['carpeta' => 'ejercicio03', 'titulo' => 'Ejercicio 3', 'detalle' => 'Pendiente de desarrollar.', 'listo' => false],
    ['carpeta' => 'ejercicio04', 'titulo' => 'Ejercicio 4', 'detalle' => 'Pendiente de desarrollar.', 'listo' => false],
    ['carpeta' => 'ejercicio05', 'titulo' => 'Ejercicio 5', 'detalle' => 'Pendiente de desarrollar.', 'listo' => false],
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($nombreTarea, ENT_QUOTES, 'UTF-8') ?> - <?= htmlspecialchars($asignatura, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700&family=Source+Sans+3:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/portal.css">
</head>
<body>

<header class="portada">
  <div class="portada-in">
    <p class="materia"><?= htmlspecialchars($asignatura, ENT_QUOTES, 'UTF-8') ?></p>
    <h1><?= htmlspecialchars($nombreTarea, ENT_QUOTES, 'UTF-8') ?></h1>
    <p class="lema">Sistemas web con HTML, CSS, JavaScript, PHP y MySQL.</p>

    <h2 class="titulo-equipo">Integrantes</h2>
    <ul class="integrantes">
      <?php foreach ($integrantes as $nombre): ?>
        <li><?= htmlspecialchars($nombre, ENT_QUOTES, 'UTF-8') ?></li>
      <?php endforeach; ?>
    </ul>
  </div>
</header>

<main class="principal">
  <h2>Ejercicios</h2>

  <ol class="ejercicios">
    <?php foreach ($ejercicios as $i => $ej): ?>
      <li class="<?= $ej['listo'] ? '' : 'pendiente' ?>">
        <a href="<?= $ej['carpeta'] ?>/index.php">
          <span class="num"><?= $i + 1 ?></span>
          <span class="texto">
            <strong><?= htmlspecialchars($ej['titulo'], ENT_QUOTES, 'UTF-8') ?></strong>
            <span><?= htmlspecialchars($ej['detalle'], ENT_QUOTES, 'UTF-8') ?></span>
          </span>
          <span class="estado"><?= $ej['listo'] ? 'Abrir' : 'Pendiente' ?></span>
        </a>
      </li>
    <?php endforeach; ?>
  </ol>

</main>

<footer class="pie">
  Hecho con PHP <?= PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION ?> y MySQL.
</footer>

</body>
</html>
