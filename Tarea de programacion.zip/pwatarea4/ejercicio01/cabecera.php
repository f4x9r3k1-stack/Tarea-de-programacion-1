<?php
// Parte de arriba que comparten todas las páginas.
// Cada página define antes $titulo y, si quiere, $sin_menu = true.
$u = usuario_actual();
$sin_menu = $sin_menu ?? false;
$actual = basename($_SERVER['SCRIPT_NAME']);
$aviso = leer_flash();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="csrf" content="<?= e(csrf_token()) ?>">
  <title><?= e($titulo ?? 'Tareas') ?> - Ejercicio 1</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;700&family=Source+Sans+3:wght@400;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="<?= $sin_menu ? 'pagina-acceso' : '' ?>">

<?php if (!$sin_menu && $u): ?>
<header class="barra">
  <div class="barra-in">
    <a class="marca" href="tareas.php">Lista de tareas</a>

    <nav class="menu" aria-label="Principal">
      <a href="tareas.php" class="<?= $actual === 'tareas.php' ? 'activo' : '' ?>">Tareas</a>
      <?php if (puede('gestionar_usuarios')): ?>
        <a href="admin.php" class="<?= $actual === 'admin.php' ? 'activo' : '' ?>">Usuarios</a>
      <?php endif; ?>
      <a href="../index.php">Portal</a>
    </nav>

    <div class="sesion">
      <span class="quien"><?= e($u['nombre']) ?></span>
      <span class="rol rol-<?= e($u['rol']) ?>"><?= e($u['rol']) ?></span>
      <a class="salir" href="logout.php">Salir</a>
    </div>
  </div>
</header>
<?php endif; ?>

<main class="contenedor">
<?php if ($aviso): ?>
  <div class="aviso aviso-<?= e($aviso['tipo']) ?>" role="status"><?= e($aviso['mensaje']) ?></div>
<?php endif; ?>
