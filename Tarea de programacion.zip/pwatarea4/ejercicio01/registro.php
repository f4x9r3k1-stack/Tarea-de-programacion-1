<?php
require_once 'funciones.php';

if (usuario_actual()) {
    redirigir('tareas.php');
}

$errores = [];
$nombre = '';
$usuario = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre   = trim($_POST['nombre'] ?? '');
    $usuario  = trim($_POST['usuario'] ?? '');
    $clave    = $_POST['clave'] ?? '';
    $clave2   = $_POST['clave2'] ?? '';

    if (!csrf_valido($_POST['csrf'] ?? null)) {
        $errores[] = 'La página estuvo abierta demasiado tiempo. Vuelve a intentarlo.';
    }
    if (mb_strlen($nombre) < 3 || mb_strlen($nombre) > 60) {
        $errores[] = 'El nombre debe tener entre 3 y 60 caracteres.';
    }
    if (!preg_match('/^[a-zA-Z0-9_]{3,30}$/', $usuario)) {
        $errores[] = 'El usuario solo puede llevar letras, números y guion bajo (3 a 30 caracteres).';
    }
    if (strlen($clave) < 6) {
        $errores[] = 'La contraseña debe tener al menos 6 caracteres.';
    }
    if ($clave !== $clave2) {
        $errores[] = 'Las dos contraseñas no coinciden.';
    }

    if (!$errores) {
        $db = conectar();

        $st = $db->prepare('SELECT COUNT(*) FROM usuarios WHERE usuario = ?');
        $st->execute([$usuario]);

        if ($st->fetchColumn() > 0) {
            $errores[] = 'Ese nombre de usuario ya está ocupado.';
        } else {
            // Todo registro nuevo entra con el rol "usuario".
            // Solo un admin puede cambiarlo después.
            $rol = $db->query("SELECT id FROM roles WHERE nombre = 'usuario'")->fetchColumn();

            $st = $db->prepare('INSERT INTO usuarios (nombre, usuario, clave, rol_id) VALUES (?, ?, ?, ?)');
            $st->execute([$nombre, $usuario, password_hash($clave, PASSWORD_DEFAULT), $rol]);

            flash('ok', 'Cuenta creada. Ya puedes iniciar sesión.');
            redirigir('login.php');
        }
    }
}

$titulo = 'Crear cuenta';
$sin_menu = true;
include 'cabecera.php';
?>

<section class="acceso acceso-simple">
  <div class="acceso-form">
    <h1>Crear una cuenta</h1>
    <p class="sub">Tu cuenta empezará con el rol <strong>usuario</strong>.</p>

    <?php if ($errores): ?>
      <div class="aviso aviso-error" role="alert">
        <ul>
          <?php foreach ($errores as $err): ?>
            <li><?= e($err) ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    <?php endif; ?>

    <form method="post" novalidate>
      <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

      <label for="nombre">Nombre completo</label>
      <input type="text" id="nombre" name="nombre" value="<?= e($nombre) ?>" maxlength="60" required autofocus>

      <label for="usuario">Usuario</label>
      <input type="text" id="usuario" name="usuario" value="<?= e($usuario) ?>" maxlength="30" autocomplete="username" required>

      <label for="clave">Contraseña</label>
      <input type="password" id="clave" name="clave" autocomplete="new-password" required>

      <label for="clave2">Repite la contraseña</label>
      <input type="password" id="clave2" name="clave2" autocomplete="new-password" required>

      <button type="submit" class="btn btn-principal btn-ancho">Crear cuenta</button>
    </form>

    <p class="pie-form">¿Ya tienes cuenta? <a href="login.php">Iniciar sesión</a></p>
  </div>
</section>

<?php include 'pie.php'; ?>
