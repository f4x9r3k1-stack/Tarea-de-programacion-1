<?php
require_once 'funciones.php';
$u = requiere_permiso('gestionar_usuarios');
$db = conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valido($_POST['csrf'] ?? null)) {
        flash('error', 'Petición no válida. Vuelve a intentarlo.');
        redirigir('admin.php');
    }

    $accion = $_POST['accion'] ?? '';
    $id     = (int)($_POST['id'] ?? 0);

    // Para no quedarse sin administrador, nadie puede tocar su propia cuenta desde aquí
    if ($id === (int)$u['id']) {
        flash('error', 'No puedes cambiar ni eliminar tu propia cuenta.');
        redirigir('admin.php');
    }

    if ($accion === 'rol') {
        $rol = (int)($_POST['rol_id'] ?? 0);
        $st = $db->prepare('SELECT COUNT(*) FROM roles WHERE id = ?');
        $st->execute([$rol]);

        if ($st->fetchColumn()) {
            $db->prepare('UPDATE usuarios SET rol_id = ? WHERE id = ?')->execute([$rol, $id]);
            flash('ok', 'Rol actualizado.');
        } else {
            flash('error', 'El rol elegido no existe.');
        }
    } elseif ($accion === 'eliminar') {
        $db->prepare('DELETE FROM usuarios WHERE id = ?')->execute([$id]);
        flash('ok', 'Usuario eliminado junto con las tareas que tenía asignadas.');
    }

    redirigir('admin.php');
}

$roles = $db->query('SELECT id, nombre, descripcion FROM roles ORDER BY id')->fetchAll();

$usuarios = $db->query(
    'SELECT u.id, u.nombre, u.usuario, u.rol_id, u.creado_en,
            (SELECT COUNT(*) FROM tareas t WHERE t.asignado_a = u.id) AS n_tareas
       FROM usuarios u
   ORDER BY u.nombre'
)->fetchAll();

// Matriz de permisos: qué rol tiene cada permiso
$permisos = $db->query('SELECT id, clave, descripcion FROM permisos ORDER BY id')->fetchAll();
$matriz = [];
foreach ($db->query('SELECT rol_id, permiso_id FROM rol_permiso') as $fila) {
    $matriz[$fila['rol_id']][$fila['permiso_id']] = true;
}

$titulo = 'Usuarios';
$scripts = ['js/app.js'];
include 'cabecera.php';
?>

<div class="encabezado-pagina">
  <h1>Usuarios y roles</h1>
  <p class="sub">Cambia el rol de cada persona. El cambio se aplica en su siguiente clic.</p>
</div>

<section class="bloque">
  <div class="tabla-scroll">
    <table class="tabla">
      <thead>
        <tr>
          <th>Nombre</th>
          <th>Usuario</th>
          <th>Tareas</th>
          <th>Rol</th>
          <th><span class="solo-lectores">Acciones</span></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($usuarios as $f): $esYo = $f['id'] == $u['id']; ?>
        <tr>
          <td><?= e($f['nombre']) ?><?= $esYo ? ' <span class="yo">(tú)</span>' : '' ?></td>
          <td><?= e($f['usuario']) ?></td>
          <td><?= (int)$f['n_tareas'] ?></td>
          <td>
            <form method="post" class="form-rol">
              <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
              <input type="hidden" name="accion" value="rol">
              <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
              <select name="rol_id" aria-label="Rol de <?= e($f['nombre']) ?>" <?= $esYo ? 'disabled' : '' ?>>
                <?php foreach ($roles as $r): ?>
                  <option value="<?= (int)$r['id'] ?>" <?= $r['id'] == $f['rol_id'] ? 'selected' : '' ?>><?= e($r['nombre']) ?></option>
                <?php endforeach; ?>
              </select>
              <?php if (!$esYo): ?><button type="submit" class="btn btn-suave">Guardar rol</button><?php endif; ?>
            </form>
          </td>
          <td>
            <?php if (!$esYo): ?>
              <form method="post" data-confirmar="¿Eliminar a <?= e($f['nombre']) ?>? También se borrarán las tareas que tiene asignadas.">
                <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">
                <input type="hidden" name="accion" value="eliminar">
                <input type="hidden" name="id" value="<?= (int)$f['id'] ?>">
                <button type="submit" class="btn btn-peligro">Eliminar</button>
              </form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<section class="bloque">
  <h2>Qué puede hacer cada rol</h2>
  <div class="tabla-scroll">
    <table class="tabla tabla-permisos">
      <thead>
        <tr>
          <th>Permiso</th>
          <?php foreach ($roles as $r): ?><th class="centro"><?= e($r['nombre']) ?></th><?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($permisos as $p): ?>
        <tr>
          <td><?= e($p['descripcion']) ?></td>
          <?php foreach ($roles as $r): ?>
            <td class="centro">
              <?php if (!empty($matriz[$r['id']][$p['id']])): ?>
                <span class="si" aria-label="Sí">Sí</span>
              <?php else: ?>
                <span class="no" aria-label="No">-</span>
              <?php endif; ?>
            </td>
          <?php endforeach; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<?php include 'pie.php'; ?>
