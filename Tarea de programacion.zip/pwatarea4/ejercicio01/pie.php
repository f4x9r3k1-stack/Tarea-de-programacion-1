</main>

<div id="toasts" class="toasts" aria-live="polite"></div>

<?php foreach (($scripts ?? []) as $js): ?>
  <script src="<?= e($js) ?>"></script>
<?php endforeach; ?>
</body>
</html>
