// Interacción de la lista de tareas: crear, marcar y eliminar sin recargar,
// más el filtro por estado y la búsqueda. Habla con acciones.php por fetch.
(function () {
  'use strict';

  var metaCsrf = document.querySelector('meta[name="csrf"]');
  var csrf = metaCsrf ? metaCsrf.content : '';

  var lista = document.getElementById('lista-tareas');
  var formTarea = document.getElementById('form-tarea');
  var buscador = document.getElementById('buscar');
  var filtroActual = 'todas';

  /* ---------- avisos flotantes ---------- */

  function toast(mensaje, tipo) {
    var cont = document.getElementById('toasts');
    if (!cont) return;
    var t = document.createElement('div');
    t.className = 'toast toast-' + (tipo || 'ok');
    t.textContent = mensaje;
    cont.appendChild(t);
    setTimeout(function () {
      t.classList.add('toast-fuera');
      setTimeout(function () { t.remove(); }, 300);
    }, 3200);
  }

  /* ---------- petición al servidor ---------- */

  function enviar(datos) {
    var cuerpo = new FormData();
    cuerpo.append('csrf', csrf);
    Object.keys(datos).forEach(function (k) { cuerpo.append(k, datos[k]); });

    return fetch('acciones.php', { method: 'POST', body: cuerpo, credentials: 'same-origin' })
      .then(function (resp) {
        return resp.json().then(function (json) {
          if (resp.status === 401) {
            setTimeout(function () { window.location.href = 'login.php'; }, 1500);
          }
          return json;
        });
      })
      .catch(function () {
        return { ok: false, mensaje: 'No se pudo conectar con el servidor.' };
      });
  }

  /* ---------- contadores, filtros y búsqueda ---------- */

  function actualizarContadores() {
    if (!lista) return;
    var items = lista.querySelectorAll('.tarea');
    var hechas = lista.querySelectorAll('.tarea[data-estado="hecha"]').length;

    document.getElementById('n-todas').textContent = items.length;
    document.getElementById('n-hecha').textContent = hechas;
    document.getElementById('n-pendiente').textContent = items.length - hechas;

    document.getElementById('vacio').hidden = items.length > 0;
  }

  function aplicarFiltros() {
    if (!lista) return;
    var texto = buscador ? buscador.value.trim().toLowerCase() : '';
    var items = lista.querySelectorAll('.tarea');
    var visibles = 0;

    items.forEach(function (li) {
      var okEstado = filtroActual === 'todas' || li.dataset.estado === filtroActual;
      var okTexto = texto === '' || li.dataset.texto.indexOf(texto) !== -1;
      li.hidden = !(okEstado && okTexto);
      if (!li.hidden) visibles++;
    });

    document.getElementById('sin-resultados').hidden = !(items.length > 0 && visibles === 0);
  }

  document.querySelectorAll('.filtro').forEach(function (btn) {
    btn.addEventListener('click', function () {
      document.querySelectorAll('.filtro').forEach(function (b) { b.classList.remove('activo'); });
      btn.classList.add('activo');
      filtroActual = btn.dataset.filtro;
      aplicarFiltros();
    });
  });

  if (buscador) buscador.addEventListener('input', aplicarFiltros);

  /* ---------- crear tarea ---------- */

  if (formTarea) {
    formTarea.addEventListener('submit', function (ev) {
      ev.preventDefault();

      var campoTitulo = document.getElementById('titulo');
      if (campoTitulo.value.trim() === '') {
        campoTitulo.classList.add('invalido');
        campoTitulo.focus();
        toast('Escribe un título para la tarea.', 'error');
        return;
      }
      campoTitulo.classList.remove('invalido');

      var boton = formTarea.querySelector('button[type="submit"]');
      boton.disabled = true;

      var datos = { accion: 'crear' };
      new FormData(formTarea).forEach(function (valor, clave) { datos[clave] = valor; });

      enviar(datos).then(function (r) {
        boton.disabled = false;

        if (!r.ok) {
          toast(r.mensaje, 'error');
          return;
        }

        if (r.visible) {
          lista.insertAdjacentHTML('afterbegin', r.html);
          actualizarContadores();
          aplicarFiltros();
          toast(r.mensaje, 'ok');
        } else {
          toast('Tarea creada y asignada a otra persona.', 'ok');
        }

        formTarea.reset();
        campoTitulo.focus();
      });
    });

    document.getElementById('titulo').addEventListener('input', function () {
      this.classList.remove('invalido');
    });
  }

  /* ---------- marcar y eliminar (delegación de eventos) ---------- */

  function hoyISO() {
    var d = new Date();
    var mes = String(d.getMonth() + 1).padStart(2, '0');
    var dia = String(d.getDate()).padStart(2, '0');
    return d.getFullYear() + '-' + mes + '-' + dia;
  }

  function refrescarVencida(li) {
    var limite = li.dataset.limite;
    var vencida = li.dataset.estado !== 'hecha' && limite && limite < hoyISO();
    li.classList.toggle('vencida', !!vencida);
    var pref = li.querySelector('.fecha-pref');
    if (pref) pref.textContent = vencida ? 'Venció el' : 'Entrega';
  }

  if (lista) {
    lista.addEventListener('change', function (ev) {
      if (!ev.target.classList.contains('chk-marcar')) return;

      var chk = ev.target;
      var li = chk.closest('.tarea');
      var quiereHecha = chk.checked;

      chk.disabled = true;
      enviar({ accion: 'marcar', id: li.dataset.id, hecha: quiereHecha ? '1' : '0' }).then(function (r) {
        chk.disabled = false;

        if (!r.ok) {
          chk.checked = !quiereHecha; // se deshace el cambio visual
          toast(r.mensaje, 'error');
          return;
        }

        li.classList.toggle('hecha', r.hecha);
        li.dataset.estado = r.hecha ? 'hecha' : 'pendiente';
        refrescarVencida(li);
        actualizarContadores();
        toast(r.mensaje, 'ok');

        // si hay un filtro activo, la tarea puede dejar de corresponder
        setTimeout(aplicarFiltros, 350);
      });
    });

    lista.addEventListener('click', function (ev) {
      var btn = ev.target.closest('.btn-borrar');
      if (!btn) return;

      var li = btn.closest('.tarea');
      var nombre = li.querySelector('.titulo').textContent;
      if (!window.confirm('¿Eliminar la tarea "' + nombre + '"? Esta acción no se puede deshacer.')) return;

      btn.disabled = true;
      enviar({ accion: 'eliminar', id: li.dataset.id }).then(function (r) {
        if (!r.ok) {
          btn.disabled = false;
          toast(r.mensaje, 'error');
          return;
        }
        li.classList.add('saliendo');
        setTimeout(function () {
          li.remove();
          actualizarContadores();
          aplicarFiltros();
        }, 250);
        toast(r.mensaje, 'ok');
      });
    });
  }

  /* ---------- confirmación en formularios del panel de usuarios ---------- */

  document.querySelectorAll('form[data-confirmar]').forEach(function (f) {
    f.addEventListener('submit', function (ev) {
      if (!window.confirm(f.dataset.confirmar)) ev.preventDefault();
    });
  });

})();
