<?php
// Punto de entrada del ejercicio: manda al panel si hay sesión, si no al login.
require_once 'funciones.php';
redirigir(usuario_actual() ? 'tareas.php' : 'login.php');
