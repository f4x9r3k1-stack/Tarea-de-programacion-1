-- Base de datos del Ejercicio 1: Lista de tareas con roles y permisos
-- Versión para hosting: la base de datos ya la creaste en el panel del hosting.
-- Impórtalo dentro de esa base (phpMyAdmin, pestaña "Importar").


DROP TABLE IF EXISTS tareas;
DROP TABLE IF EXISTS rol_permiso;
DROP TABLE IF EXISTS usuarios;
DROP TABLE IF EXISTS permisos;
DROP TABLE IF EXISTS roles;

-- ---------- roles y permisos ----------

CREATE TABLE roles (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre      VARCHAR(30)  NOT NULL UNIQUE,
  descripcion VARCHAR(150) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE permisos (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  clave       VARCHAR(40)  NOT NULL UNIQUE,
  descripcion VARCHAR(150) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE rol_permiso (
  rol_id     INT UNSIGNED NOT NULL,
  permiso_id INT UNSIGNED NOT NULL,
  PRIMARY KEY (rol_id, permiso_id),
  FOREIGN KEY (rol_id)     REFERENCES roles(id)    ON DELETE CASCADE,
  FOREIGN KEY (permiso_id) REFERENCES permisos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- usuarios ----------

CREATE TABLE usuarios (
  id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nombre     VARCHAR(60)  NOT NULL,
  usuario    VARCHAR(30)  NOT NULL UNIQUE,
  clave      VARCHAR(255) NOT NULL,
  rol_id     INT UNSIGNED NOT NULL,
  creado_en  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (rol_id) REFERENCES roles(id)
) ENGINE=InnoDB;

-- ---------- tareas ----------

CREATE TABLE tareas (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  titulo        VARCHAR(120) NOT NULL,
  descripcion   VARCHAR(500) NULL,
  prioridad     ENUM('baja','media','alta') NOT NULL DEFAULT 'media',
  fecha_limite  DATE NULL,
  completada    TINYINT(1) NOT NULL DEFAULT 0,
  completada_en DATETIME NULL,
  creado_por    INT UNSIGNED NULL,
  asignado_a    INT UNSIGNED NOT NULL,
  creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (creado_por) REFERENCES usuarios(id) ON DELETE SET NULL,
  FOREIGN KEY (asignado_a) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------- datos iniciales ----------

INSERT INTO roles (id, nombre, descripcion) VALUES
  (1, 'admin',   'Administra usuarios y todas las tareas'),
  (2, 'usuario', 'Gestiona sus propias tareas'),
  (3, 'lector',  'Solo puede consultar sus tareas');

INSERT INTO permisos (id, clave, descripcion) VALUES
  (1, 'ver_todas',         'Ver las tareas de todos los usuarios'),
  (2, 'crear',             'Agregar tareas'),
  (3, 'asignar',           'Asignar una tarea a otro usuario'),
  (4, 'marcar_propias',    'Marcar como hechas las tareas asignadas a uno mismo'),
  (5, 'marcar_todas',      'Marcar como hechas las tareas de cualquier usuario'),
  (6, 'eliminar_propias',  'Eliminar las tareas que uno mismo creó'),
  (7, 'eliminar_todas',    'Eliminar cualquier tarea'),
  (8, 'gestionar_usuarios','Cambiar roles y eliminar usuarios');

-- admin: todos los permisos
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
  (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8);
-- usuario: crear, marcar y eliminar lo suyo
INSERT INTO rol_permiso (rol_id, permiso_id) VALUES
  (2,2),(2,4),(2,6);
-- lector: sin permisos de escritura

-- Contraseñas de prueba:
--   admin / Admin123*     maria / Usuario123*     luis / Lector123*
INSERT INTO usuarios (id, nombre, usuario, clave, rol_id) VALUES
  (1, 'Administrador', 'admin', '$2b$10$uy0PimBbXeofL7e6TAi2qOc/9wF1YVja39RQyEl2JxvSBsYxVS6Fi', 1),
  (2, 'María Andrade', 'maria', '$2b$10$Krt3uXorEeq8t1cryXFGMOhlVvhqBbSSlqIoVDDgOAjlKrrBPhl5q', 2),
  (3, 'Luis Paredes',  'luis',  '$2b$10$bSPDrjmefkjazP3g3W1uO.f1TcxLt.E9ViBAUr7F/vEU9JF2/FNc6', 3);

INSERT INTO tareas (titulo, descripcion, prioridad, fecha_limite, completada, completada_en, creado_por, asignado_a) VALUES
  ('Revisar el material de la unidad 4', 'Leer los capítulos de PHP y MySQL del libro de Nixon.', 'alta', DATE_ADD(CURDATE(), INTERVAL 3 DAY), 0, NULL, 1, 2),
  ('Subir el repositorio a GitHub', 'El repositorio debe llamarse pwatarea4.', 'media', DATE_ADD(CURDATE(), INTERVAL 5 DAY), 0, NULL, 2, 2),
  ('Probar el formulario de login', NULL, 'baja', NULL, 1, NOW(), 2, 2),
  ('Preparar el reporte semanal', 'Resumen de avances para la reunión del viernes.', 'alta', DATE_SUB(CURDATE(), INTERVAL 1 DAY), 0, NULL, 1, 1),
  ('Leer las notas de la clase', 'Solo consulta, no requiere entrega.', 'baja', NULL, 0, NULL, 1, 3);
